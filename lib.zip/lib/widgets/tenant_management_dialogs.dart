
import 'package:flutter/material.dart';

// -----------------------------------------------------------------------------
// COLORS
// -----------------------------------------------------------------------------

const Color _navy = Color(0xFF172554);
const Color _blue = Color(0xFF3157F6);
const Color _green = Color(0xFF16A34A);
const Color _red = Color(0xFFDC3545);
const Color _text = Color(0xFF172033);
const Color _muted = Color(0xFF718096);
const Color _border = Color(0xFFE2E8F0);
const Color _surface = Colors.white;

// -----------------------------------------------------------------------------
// RESULT MODELS
// -----------------------------------------------------------------------------

class TenantConfigureResult {
  final String plan;
  final String region;
  final String storageLimit;
  final String status;

  const TenantConfigureResult({
    required this.plan,
    required this.region,
    required this.storageLimit,
    required this.status,
  });
}

enum TenantExportFormat { excel, csv, pdf }

class TenantExportOptions {
  final TenantExportFormat format;
  final bool allTenants;
  final Set<String> columns;

  const TenantExportOptions({
    required this.format,
    required this.allTenants,
    required this.columns,
  });
}

class TenantBackupOptions {
  final String backupType;
  final String storageLocation;

  const TenantBackupOptions({
    required this.backupType,
    required this.storageLocation,
  });
}

// -----------------------------------------------------------------------------
// COMMON DIALOG SHELL
// -----------------------------------------------------------------------------

Widget _dialogShell({
  required BuildContext context,
  required Widget child,
  double maxWidth = 430,
}) {
  return Dialog(
    backgroundColor: _surface,
    elevation: 12,
    insetPadding: const EdgeInsets.symmetric(
      horizontal: 16,
      vertical: 24,
    ),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
    child: ConstrainedBox(
      constraints: BoxConstraints(
        maxWidth: maxWidth,
        maxHeight: MediaQuery.of(context).size.height * 0.88,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: child,
      ),
    ),
  );
}

Widget _dialogHeading({
  required String title,
  required String subtitle,
  required IconData icon,
  required Color iconColor,
  required Color iconBackground,
  required VoidCallback onClose,
}) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: iconBackground,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor, size: 21),
      ),
      const SizedBox(width: 13),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: _text,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: const TextStyle(
                fontSize: 11,
                color: _muted,
              ),
            ),
          ],
        ),
      ),
      InkWell(
        onTap: onClose,
        borderRadius: BorderRadius.circular(20),
        child: const Padding(
          padding: EdgeInsets.all(3),
          child: Icon(Icons.close, size: 17, color: _muted),
        ),
      ),
    ],
  );
}

Widget _dialogButton({
  required String label,
  required VoidCallback onPressed,
  required Color color,
  IconData? icon,
  bool outlined = false,
}) {
  return SizedBox(
    height: 36,
    child: outlined
        ? OutlinedButton(
            onPressed: onPressed,
            style: OutlinedButton.styleFrom(
              foregroundColor: _text,
              side: const BorderSide(color: _border),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 17),
            ),
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          )
        : ElevatedButton.icon(
            onPressed: onPressed,
            icon: Icon(icon ?? Icons.check_circle_outline, size: 14),
            label: Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: color,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 15),
            ),
          ),
  );
}

// -----------------------------------------------------------------------------
// TENANT ENABLE / DISABLE CONFIRMATION
// -----------------------------------------------------------------------------

Future<bool?> showTenantStatusDialog({
  required BuildContext context,
  required String tenantName,
  required String tenantDescription,
  required bool enable,
}) {
  final title = enable ? 'Enable Tenant' : 'Disable Tenant';
  final color = enable ? _green : _red;

  final message = enable
      ? 'Once enabled, the tenant will be able to access the platform.'
      : 'Once disabled, the tenant will no longer be able to access the platform.';

  return showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return _dialogShell(
        context: dialogContext,
        maxWidth: 460,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _dialogHeading(
              title: title,
              subtitle: 'Are you sure you want to ${enable ? 'enable' : 'disable'} this tenant?',
              icon: enable
                  ? Icons.check_circle_outline
                  : Icons.block_outlined,
              iconColor: color,
              iconBackground: enable
                  ? const Color(0xFFECFDF5)
                  : const Color(0xFFFFF1F2),
              onClose: () => Navigator.pop(dialogContext),
            ),
            const SizedBox(height: 16),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: enable
                    ? const Color(0xFFF0FDF4)
                    : const Color(0xFFFFF1F2),
                border: Border.all(
                  color: enable
                      ? const Color(0xFFD1FAE5)
                      : const Color(0xFFFFD5DA),
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                message,
                style: TextStyle(
                  fontSize: 11,
                  height: 1.5,
                  color: enable
                      ? const Color(0xFF15803D)
                      : const Color(0xFFBE123C),
                ),
              ),
            ),

            const SizedBox(height: 14),

            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                    color: _blue,
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    tenantName.isNotEmpty
                        ? tenantName[0].toUpperCase()
                        : 'T',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tenantName,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: _text,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        tenantDescription,
                        style: const TextStyle(
                          fontSize: 10,
                          color: _muted,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            Wrap(
              alignment: WrapAlignment.end,
              spacing: 9,
              runSpacing: 8,
              children: [
                _dialogButton(
                  label: 'Cancel',
                  color: color,
                  outlined: true,
                  onPressed: () => Navigator.pop(dialogContext, false),
                ),
                _dialogButton(
                  label: enable ? 'Enable Tenant' : 'Disable Tenant',
                  color: color,
                  onPressed: () => Navigator.pop(dialogContext, true),
                ),
              ],
            ),
          ],
        ),
      );
    },
  );
}

// -----------------------------------------------------------------------------
// CONFIGURE TENANT
// -----------------------------------------------------------------------------

Future<TenantConfigureResult?> showConfigureTenantDialog({
  required BuildContext context,
  required String tenantName,
  String initialPlan = 'Enterprise',
  String initialRegion = 'India (Asia South)',
  String initialStorage = '200',
  String initialStatus = 'Active',
}) {
  return showDialog<TenantConfigureResult>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return _ConfigureTenantDialog(
        tenantName: tenantName,
        initialPlan: initialPlan,
        initialRegion: initialRegion,
        initialStorage: initialStorage,
        initialStatus: initialStatus,
      );
    },
  );
}

class _ConfigureTenantDialog extends StatefulWidget {
  final String tenantName;
  final String initialPlan;
  final String initialRegion;
  final String initialStorage;
  final String initialStatus;

  const _ConfigureTenantDialog({
    required this.tenantName,
    required this.initialPlan,
    required this.initialRegion,
    required this.initialStorage,
    required this.initialStatus,
  });

  @override
  State<_ConfigureTenantDialog> createState() =>
      _ConfigureTenantDialogState();
}

class _ConfigureTenantDialogState extends State<_ConfigureTenantDialog> {
  late String plan;
  late String region;
  late String storage;
  late String status;

  final storageController = TextEditingController();

  @override
  void initState() {
    super.initState();
    plan = widget.initialPlan;
    region = widget.initialRegion;
    storage = widget.initialStorage;
    status = widget.initialStatus;
    storageController.text = storage;
  }

  @override
  void dispose() {
    storageController.dispose();
    super.dispose();
  }

  Widget _fieldLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w700,
          color: _text,
        ),
      ),
    );
  }

  Widget _dropdown({
    required String value,
    required List<String> options,
    required ValueChanged<String?> onChanged,
  }) {
    return SizedBox(
      height: 36,
      child: DropdownButtonFormField<String>(
        value: value,
        isExpanded: true,
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 7,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
            borderSide: const BorderSide(color: _border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
            borderSide: const BorderSide(color: _border),
          ),
        ),
        style: const TextStyle(fontSize: 11, color: _text),
        iconSize: 16,
        items: options
            .map(
              (item) => DropdownMenuItem(
                value: item,
                child: Text(item, overflow: TextOverflow.ellipsis),
              ),
            )
            .toList(),
        onChanged: onChanged,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _dialogShell(
      context: context,
      maxWidth: 440,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _dialogHeading(
            title: 'Configure Tenant',
            subtitle: 'Update the key settings for ${widget.tenantName}.',
            icon: Icons.settings_outlined,
            iconColor: _blue,
            iconBackground: const Color(0xFFEFF6FF),
            onClose: () => Navigator.pop(context),
          ),
          const SizedBox(height: 18),

          _fieldLabel('Subscription Plan'),
          _dropdown(
            value: plan,
            options: const ['Enterprise', 'Professional', 'Standard'],
            onChanged: (value) {
              if (value != null) setState(() => plan = value);
            },
          ),
          const SizedBox(height: 5),
          const Text(
            'Defines feature access and usage limits.',
            style: TextStyle(fontSize: 9, color: _muted),
          ),

          const SizedBox(height: 14),

          _fieldLabel('Region'),
          _dropdown(
            value: region,
            options: const [
              'India (Asia South)',
              'US East',
              'US West',
              'Europe',
              'Asia Pacific',
            ],
            onChanged: (value) {
              if (value != null) setState(() => region = value);
            },
          ),
          const SizedBox(height: 5),
          const Text(
            'Select the primary region for this tenant.',
            style: TextStyle(fontSize: 9, color: _muted),
          ),

          const SizedBox(height: 14),

          _fieldLabel('Storage Limit'),
          SizedBox(
            height: 36,
            child: TextField(
              controller: storageController,
              keyboardType: TextInputType.number,
              style: const TextStyle(fontSize: 11, color: _text),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                suffixText: 'GB',
                suffixStyle: const TextStyle(fontSize: 10, color: _muted),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: const BorderSide(color: _border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: const BorderSide(color: _border),
                ),
              ),
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Maximum storage allowed for this tenant.',
            style: TextStyle(fontSize: 9, color: _muted),
          ),

          const SizedBox(height: 14),

          _fieldLabel('Status'),
          RadioListTile<String>(
            value: 'Active',
            groupValue: status,
            dense: true,
            contentPadding: EdgeInsets.zero,
            visualDensity: VisualDensity.compact,
            activeColor: _blue,
            title: const Text(
              'Active',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
            ),
            subtitle: const Text(
              'Tenant can access the platform',
              style: TextStyle(fontSize: 9, color: _muted),
            ),
            onChanged: (value) {
              if (value != null) setState(() => status = value);
            },
          ),
          RadioListTile<String>(
            value: 'Inactive',
            groupValue: status,
            dense: true,
            contentPadding: EdgeInsets.zero,
            visualDensity: VisualDensity.compact,
            activeColor: _blue,
            title: const Text(
              'Inactive',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
            ),
            subtitle: const Text(
              'Tenant access will be restricted',
              style: TextStyle(fontSize: 9, color: _muted),
            ),
            onChanged: (value) {
              if (value != null) setState(() => status = value);
            },
          ),

          const SizedBox(height: 12),

          Wrap(
            alignment: WrapAlignment.end,
            spacing: 9,
            runSpacing: 8,
            children: [
              _dialogButton(
                label: 'Cancel',
                color: _blue,
                outlined: true,
                onPressed: () => Navigator.pop(context),
              ),
              _dialogButton(
                label: 'Save Changes',
                color: _blue,
                icon: Icons.save_outlined,
                onPressed: () {
                  Navigator.pop(
                    context,
                    TenantConfigureResult(
                      plan: plan,
                      region: region,
                      storageLimit: storageController.text.trim(),
                      status: status,
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// BACKUP TENANT
// -----------------------------------------------------------------------------

Future<TenantBackupOptions?> showBackupTenantDialog({
  required BuildContext context,
  required String tenantName,
}) {
  return showDialog<TenantBackupOptions>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return _BackupTenantDialog(tenantName: tenantName);
    },
  );
}

class _BackupTenantDialog extends StatefulWidget {
  final String tenantName;

  const _BackupTenantDialog({required this.tenantName});

  @override
  State<_BackupTenantDialog> createState() => _BackupTenantDialogState();
}

class _BackupTenantDialogState extends State<_BackupTenantDialog> {
  String backupType = 'Full Backup';
  String storageLocation = 'Cloud Storage (Default)';

  @override
  Widget build(BuildContext context) {
    return _dialogShell(
      context: context,
      maxWidth: 420,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _dialogHeading(
            title: 'Backup Tenant',
            subtitle: 'Create a backup for ${widget.tenantName}.',
            icon: Icons.backup_outlined,
            iconColor: _blue,
            iconBackground: const Color(0xFFEFF6FF),
            onClose: () => Navigator.pop(context),
          ),
          const SizedBox(height: 20),

          const Text(
            'Backup Type',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: _text,
            ),
          ),
          const SizedBox(height: 7),

          DropdownButtonFormField<String>(
            value: backupType,
            isExpanded: true,
            decoration: _backupDecoration(),
            style: const TextStyle(fontSize: 11, color: _text),
            items: const [
              DropdownMenuItem(
                value: 'Full Backup',
                child: Text('Full Backup'),
              ),
              DropdownMenuItem(
                value: 'Incremental Backup',
                child: Text('Incremental Backup'),
              ),
              DropdownMenuItem(
                value: 'Database Backup',
                child: Text('Database Backup'),
              ),
            ],
            onChanged: (value) {
              if (value != null) setState(() => backupType = value);
            },
          ),
          const SizedBox(height: 5),
          const Text(
            'Creates a complete backup of all tenant data.',
            style: TextStyle(fontSize: 9, color: _muted),
          ),

          const SizedBox(height: 17),

          const Text(
            'Storage Location',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: _text,
            ),
          ),
          const SizedBox(height: 7),

          DropdownButtonFormField<String>(
            value: storageLocation,
            isExpanded: true,
            decoration: _backupDecoration(),
            style: const TextStyle(fontSize: 11, color: _text),
            items: const [
              DropdownMenuItem(
                value: 'Cloud Storage (Default)',
                child: Text('Cloud Storage (Default)'),
              ),
              DropdownMenuItem(
                value: 'Local Storage',
                child: Text('Local Storage'),
              ),
              DropdownMenuItem(
                value: 'External Storage',
                child: Text('External Storage'),
              ),
            ],
            onChanged: (value) {
              if (value != null) setState(() => storageLocation = value);
            },
          ),
          const SizedBox(height: 5),
          const Text(
            'Backup will be stored in the configured storage.',
            style: TextStyle(fontSize: 9, color: _muted),
          ),

          const SizedBox(height: 20),

          Wrap(
            alignment: WrapAlignment.end,
            spacing: 9,
            runSpacing: 8,
            children: [
              _dialogButton(
                label: 'Cancel',
                color: _blue,
                outlined: true,
                onPressed: () => Navigator.pop(context),
              ),
              _dialogButton(
                label: 'Start Backup',
                color: _blue,
                icon: Icons.backup_outlined,
                onPressed: () {
                  Navigator.pop(
                    context,
                    TenantBackupOptions(
                      backupType: backupType,
                      storageLocation: storageLocation,
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  InputDecoration _backupDecoration() {
    return InputDecoration(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 8,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6),
        borderSide: const BorderSide(color: _border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6),
        borderSide: const BorderSide(color: _border),
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// EXPORT TENANTS
// -----------------------------------------------------------------------------

Future<TenantExportOptions?> showExportTenantsDialog({
  required BuildContext context,
}) {
  return showDialog<TenantExportOptions>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => const _ExportTenantsDialog(),
  );
}

class _ExportTenantsDialog extends StatefulWidget {
  const _ExportTenantsDialog();

  @override
  State<_ExportTenantsDialog> createState() => _ExportTenantsDialogState();
}

class _ExportTenantsDialogState extends State<_ExportTenantsDialog> {
  TenantExportFormat format = TenantExportFormat.excel;
  bool allTenants = true;

  final Map<String, bool> columns = {
    'Tenant Name': true,
    'Tenant ID': true,
    'Domain': true,
    'Subscription Plan': true,
    'Status': true,
    'Region': true,
    'Storage Used': true,
    'Created On': true,
    'Last Backup': true,
    'Actions': true,
  };

  Widget _exportFormat(
    String title,
    String subtitle,
    TenantExportFormat value,
    Color color,
    IconData icon,
  ) {
    final selected = format == value;

    return Expanded(
      child: InkWell(
        onTap: () => setState(() => format = value),
        borderRadius: BorderRadius.circular(7),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFF8FAFF) : Colors.white,
            border: Border.all(
              color: selected ? color : _border,
              width: selected ? 1.4 : 1,
            ),
            borderRadius: BorderRadius.circular(7),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                selected
                    ? Icons.radio_button_checked
                    : Icons.radio_button_off,
                size: 13,
                color: selected ? color : _muted,
              ),
              const SizedBox(width: 5),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(icon, size: 15, color: color),
                    const SizedBox(height: 4),
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: _text,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 8,
                        height: 1.3,
                        color: _muted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _scopeOption(String title, String subtitle, bool value) {
    return InkWell(
      onTap: () => setState(() => allTenants = value),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Icon(
              allTenants == value
                  ? Icons.radio_button_checked
                  : Icons.radio_button_off,
              size: 14,
              color: allTenants == value ? _blue : _muted,
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: _text,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 8, color: _muted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _columnCheckbox(String label) {
    return SizedBox(
      width: 145,
      child: InkWell(
        onTap: () => setState(
          () => columns[label] = !(columns[label] ?? false),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 19,
              height: 23,
              child: Checkbox(
                value: columns[label],
                activeColor: _blue,
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                onChanged: (value) {
                  setState(() => columns[label] = value ?? false);
                },
              ),
            ),
            const SizedBox(width: 5),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(fontSize: 9, color: _text),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _dialogShell(
      context: context,
      maxWidth: 460,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.download_outlined,
                  size: 17,
                  color: _blue,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Export Tenants',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _text,
                      ),
                    ),
                    Text(
                      'Export tenant data in your preferred format.',
                      style: TextStyle(fontSize: 9, color: _muted),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.close, size: 16, color: _muted),
              ),
            ],
          ),

          const SizedBox(height: 14),

          const Text(
            'Export Scope',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: _text,
            ),
          ),
          const SizedBox(height: 5),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              border: Border.all(color: _border),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Column(
              children: [
                _scopeOption(
                  'All Tenants',
                  'Export data of all tenants (24 tenants)',
                  true,
                ),
                const Divider(height: 5, color: _border),
                _scopeOption(
                  'Selected Tenants',
                  'Export data of only selected tenants',
                  false,
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          const Text(
            'File Format',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: _text,
            ),
          ),
          const SizedBox(height: 6),

          Row(
            children: [
              _exportFormat(
                'Excel (.xlsx)',
                'Recommended for data analysis',
                TenantExportFormat.excel,
                const Color(0xFF16A34A),
                Icons.table_chart_outlined,
              ),
              const SizedBox(width: 7),
              _exportFormat(
                'CSV (.csv)',
                'Lightweight file format',
                TenantExportFormat.csv,
                const Color(0xFF64748B),
                Icons.description_outlined,
              ),
              const SizedBox(width: 7),
              _exportFormat(
                'PDF (.pdf)',
                'Formatted report for sharing',
                TenantExportFormat.pdf,
                _red,
                Icons.picture_as_pdf_outlined,
              ),
            ],
          ),

          const SizedBox(height: 13),

          Row(
            children: [
              const Expanded(
                child: Text(
                  'Export Columns',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: _text,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {
                  setState(() {
                    final selectAll = columns.values.any((value) => !value);
                    columns.updateAll((key, value) => selectAll);
                  });
                },
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(0, 25),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: const Text(
                  'Select All',
                  style: TextStyle(fontSize: 9, color: _blue),
                ),
              ),
            ],
          ),

          Wrap(
            spacing: 4,
            runSpacing: 0,
            children: columns.keys.map(_columnCheckbox).toList(),
          ),

          const SizedBox(height: 12),

          Wrap(
            alignment: WrapAlignment.end,
            spacing: 8,
            runSpacing: 8,
            children: [
              _dialogButton(
                label: 'Cancel',
                color: _blue,
                outlined: true,
                onPressed: () => Navigator.pop(context),
              ),
              _dialogButton(
                label: 'Export',
                color: _blue,
                icon: Icons.download_outlined,
                onPressed: () {
                  Navigator.pop(
                    context,
                    TenantExportOptions(
                      format: format,
                      allTenants: allTenants,
                      columns: columns.entries
                          .where((entry) => entry.value)
                          .map((entry) => entry.key)
                          .toSet(),
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
