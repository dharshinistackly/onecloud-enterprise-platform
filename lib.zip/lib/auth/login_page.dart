import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../routes/app_routes.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();

  bool _obscurePassword = true;
  bool _rememberMe = false;
  bool _isOtpStep = false;
  bool _isLoading = false;

  late AnimationController _pageController;
  late AnimationController _floatingController;
  late AnimationController _pulseController;

  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _pageController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _floatingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _fadeAnimation = CurvedAnimation(
      parent: _pageController,
      curve: Curves.easeOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _pageController,
        curve: Curves.easeOutCubic,
      ),
    );

    _pageController.forward();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _otpController.dispose();

    _pageController.dispose();
    _floatingController.dispose();
    _pulseController.dispose();

    super.dispose();
  }

  // Handles both login steps.
  void _login() {
    if (_isOtpStep) {
      _verifyOtp();
    } else {
      _continueToOtp();
    }
  }

  // Validates email and password before showing OTP.
  void _continueToOtp() {
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    if (email.isEmpty) {
      _showMessage('Please enter your email', Colors.red);
      return;
    }

    if (!email.contains('@')) {
      _showMessage('Please enter a valid email', Colors.red);
      return;
    }

    if (password.isEmpty) {
      _showMessage('Please enter your password', Colors.red);
      return;
    }

    if (password.length < 6) {
      _showMessage(
        'Password must contain at least 6 characters',
        Colors.red,
      );
      return;
    }

    setState(() {
      _isOtpStep = true;
    });

    _showMessage(
      'OTP sent successfully. Demo OTP: 123456',
      const Color(0xFF1677C8),
    );
  }

  // Verifies the six digit demo OTP.
  void _verifyOtp() {
    final otp = _otpController.text.trim();

    if (otp.isEmpty) {
      _showMessage('Please enter the OTP', Colors.red);
      return;
    }

    if (otp.length != 6) {
      _showMessage('OTP must contain 6 digits', Colors.red);
      return;
    }

    if (otp != '123456') {
      _showMessage(
        'Invalid OTP. Please enter 123456 for demo.',
        Colors.red,
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    context.read<AuthProvider>().completeAuthentication();

    Future.delayed(const Duration(milliseconds: 500), () {
      if (!mounted) return;

      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRoutes.home,
        (route) => false,
      );
    });
  }

  // Resends the demo OTP without changing the page.
  void _resendOtp() {
    if (!_isOtpStep) return;

    _otpController.clear();

    _showMessage(
      'A new OTP has been sent. Demo OTP: 123456',
      const Color(0xFF1677C8),
    );
  }

  // Opens social login.
  void _openSocialLogin(String provider) {
    if (_isOtpStep) return;

    Navigator.pushNamed(
      context,
      AppRoutes.socialLogin,
      arguments: provider,
    );
  }

  // Displays a small message.
  void _showMessage(String message, Color color) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: color,
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7FAFD),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;

            if (width < 750) {
              return _buildMobileLayout();
            }

            return _buildDesktopLayout();
          },
        ),
      ),
    );
  }

  // Desktop and tablet two-column layout.
  Widget _buildDesktopLayout() {
    return Row(
      children: [
        Expanded(
          flex: 52,
          child: _buildLeftPanel(),
        ),
        Expanded(
          flex: 48,
          child: _buildRightPanel(),
        ),
      ],
    );
  }

  // Mobile layout keeps only the important login area.
  Widget _buildMobileLayout() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFEAF6FF),
            Color(0xFFF7FAFD),
          ],
        ),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 20,
        ),
        child: Column(
          children: [
            _buildMobileLogo(),
            const SizedBox(height: 18),
            _buildLoginCard(),
          ],
        ),
      ),
    );
  }

  // Mobile logo.
  Widget _buildMobileLogo() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Image.asset(
        'assets/onecloud_logo.jpg',
        width: 220,
        height: 78,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) {
          return const Text(
            'OneCloud Enterprise',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF0F3D66),
            ),
          );
        },
      ),
    );
  }

  // Left side animated enterprise section.
  Widget _buildLeftPanel() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      clipBehavior: Clip.hardEdge,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFE5F5FF),
            Color(0xFFD6ECFF),
            Color(0xFFC5E4FB),
          ],
        ),
      ),
      child: Stack(
        children: [
          _buildAnimatedBackground(),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 42,
              vertical: 28,
            ),
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: _buildLeftContent(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Animated background circles.
  Widget _buildAnimatedBackground() {
    return Stack(
      children: [
        Positioned(
          top: -100,
          left: -90,
          child: AnimatedBuilder(
            animation: _pulseController,
            builder: (context, child) {
              final scale = 0.92 + (_pulseController.value * 0.08);

              return Transform.scale(
                scale: scale,
                child: Container(
                  width: 300,
                  height: 300,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF5DB9F2)
                        .withValues(alpha: 0.12),
                  ),
                ),
              );
            },
          ),
        ),
        Positioned(
          top: 80,
          right: -90,
          child: Container(
            width: 220,
            height: 220,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF8CCBFA)
                  .withValues(alpha: 0.14),
            ),
          ),
        ),
        Positioned(
          bottom: -110,
          right: -60,
          child: Container(
            width: 310,
            height: 310,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF6BB7ED)
                  .withValues(alpha: 0.14),
            ),
          ),
        ),
        AnimatedBuilder(
          animation: _floatingController,
          builder: (context, child) {
            final value = math.sin(
              _floatingController.value * math.pi * 2,
            );

            return Positioned(
              top: 75 + (value * 10),
              right: 65,
              child: _cloudIcon(),
            );
          },
        ),
      ],
    );
  }

  // Floating cloud icon.
  Widget _cloudIcon() {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.85),
        shape: BoxShape.circle,
        border: Border.all(
          color: const Color(0xFFB8DDF8),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1677C8)
                .withValues(alpha: 0.12),
            blurRadius: 18,
          ),
        ],
      ),
      child: const Icon(
        Icons.cloud_outlined,
        color: Color(0xFF1677C8),
        size: 25,
      ),
    );
  }

  // Left panel content.
  Widget _buildLeftContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLargeLogo(),
        const SizedBox(height: 48),
        const Text(
          'Everything your',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w800,
            color: Color(0xFF092F55),
            height: 1.05,
            letterSpacing: -1.2,
          ),
        ),
        const Text(
          'enterprise needs.',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w800,
            color: Color(0xFF1677C8),
            height: 1.05,
            letterSpacing: -1.2,
          ),
        ),
        const SizedBox(height: 18),
        const Text(
          'OneCloud brings enterprise services, people, workflows '
          'and intelligence together in one powerful platform.',
          style: TextStyle(
            fontSize: 14,
            height: 1.65,
            color: Color(0xFF52718D),
          ),
        ),
        const SizedBox(height: 28),
        _buildFeature(
          Icons.cloud_done_rounded,
          'Unified Cloud Platform',
          'Enterprise services connected in one place.',
          const Color(0xFF1677C8),
        ),
        const SizedBox(height: 13),
        _buildFeature(
          Icons.security_rounded,
          'Enterprise Security',
          'Secure authentication and controlled access.',
          const Color(0xFF159A82),
        ),
        const SizedBox(height: 13),
        _buildFeature(
          Icons.auto_awesome_rounded,
          'Smart Operations',
          'Powerful tools for modern enterprise teams.',
          const Color(0xFF7357D8),
        ),
        const SizedBox(height: 28),
        _buildMiniDashboard(),
      ],
    );
  }

  // Larger OneCloud logo.
  Widget _buildLargeLogo() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1677C8)
                .withValues(alpha: 0.08),
            blurRadius: 15,
          ),
        ],
      ),
      child: Image.asset(
        'assets/onecloud_logo.jpg',
        width: 230,
        height: 82,
        fit: BoxFit.contain,
        alignment: Alignment.centerLeft,
        errorBuilder: (_, __, ___) {
          return const Padding(
            padding: EdgeInsets.all(10),
            child: Text(
              'OneCloud Enterprise Platform',
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0F3D66),
              ),
            ),
          );
        },
      ),
    );
  }

  // Feature item.
  Widget _buildFeature(
    IconData icon,
    String title,
    String description,
    Color color,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withValues(alpha: 0.18),
            ),
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.10),
                blurRadius: 12,
              ),
            ],
          ),
          child: Icon(
            icon,
            color: color,
            size: 22,
          ),
        ),
        const SizedBox(width: 13),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF173B5F),
                ),
              ),
              const SizedBox(height: 3),
              Text(
                description,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF69849D),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Small dashboard illustration.
  Widget _buildMiniDashboard() {
    return Container(
      width: double.infinity,
      height: 150,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF397BAA)
                .withValues(alpha: 0.12),
            blurRadius: 25,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            height: 38,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: const BoxDecoration(
              color: Color(0xFFF8FBFE),
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(14),
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.cloud_rounded,
                  color: Color(0xFF1677C8),
                  size: 18,
                ),
                const SizedBox(width: 7),
                const Text(
                  'Enterprise Dashboard',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF25445E),
                  ),
                ),
                const Spacer(),
                _smallDot(),
                const SizedBox(width: 4),
                _smallDot(),
                const SizedBox(width: 4),
                _smallDot(),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  _dashboardBox('Users', '1,248'),
                  const SizedBox(width: 8),
                  _dashboardBox('Tenants', '48'),
                  const SizedBox(width: 8),
                  _dashboardBox('Services', '16'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Dashboard statistic box.
  Widget _dashboardBox(String title, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FBFF),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
            color: const Color(0xFFE1EDF7),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 9,
                color: Color(0xFF7590A8),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              value,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: Color(0xFF0F3D66),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Small dashboard dot.
  Widget _smallDot() {
    return Container(
      width: 6,
      height: 6,
      decoration: const BoxDecoration(
        color: Color(0xFFD7E7F3),
        shape: BoxShape.circle,
      ),
    );
  }

  // Right side login area.
  Widget _buildRightPanel() {
    return Container(
      color: const Color(0xFFF8FAFC),
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(
            horizontal: 28,
            vertical: 30,
          ),
          child: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: 390,
            ),
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: _buildLoginCard(),
            ),
          ),
        ),
      ),
    );
  }

  // Main login card.
  Widget _buildLoginCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        28,
        27,
        28,
        23,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: const Color(0xFFE9EFF5),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 30,
            offset: const Offset(0, 15),
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Text(
                'Welcome Back!',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF092F55),
                  letterSpacing: -0.7,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Center(
              child: Text(
                _isOtpStep
                    ? 'Complete the second step to continue'
                    : 'Login to your OneCloud Enterprise account',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 11.5,
                  color: Color(0xFF8195A8),
                ),
              ),
            ),
            const SizedBox(height: 21),

            _sectionTitle(
              'Email Address',
              const Color(0xFF1677C8),
            ),
            const SizedBox(height: 7),

            TextFormField(
              controller: _emailController,
              enabled: !_isLoading,
              keyboardType: TextInputType.emailAddress,
              decoration: _inputDecoration(
                hintText: 'Enter your email',
                icon: Icons.person_outline_rounded,
                color: const Color(0xFF1677C8),
              ),
            ),

            const SizedBox(height: 13),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _sectionTitle(
                  'Password',
                  const Color(0xFF7C4DFF),
                ),
                TextButton(
                  onPressed: _isLoading
                      ? null
                      : () => Navigator.pushNamed(
                            context,
                            AppRoutes.forgotPassword,
                          ),
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize:
                        MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    'Forgot Password?',
                    style: TextStyle(
                      color: Color(0xFF1677C8),
                      fontWeight: FontWeight.w700,
                      fontSize: 10.5,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 7),

            TextFormField(
              controller: _passwordController,
              enabled: !_isLoading,
              obscureText: _obscurePassword,
              decoration: _inputDecoration(
                hintText: 'Enter your password',
                icon: Icons.lock_outline_rounded,
                color: const Color(0xFF7C4DFF),
                suffixIcon: IconButton(
                  onPressed: _isLoading
                      ? null
                      : () {
                          setState(() {
                            _obscurePassword =
                                !_obscurePassword;
                          });
                        },
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: const Color(0xFF718096),
                    size: 19,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 7),

            Row(
              children: [
                SizedBox(
                  width: 19,
                  height: 19,
                  child: Checkbox(
                    value: _rememberMe,
                    onChanged: _isLoading
                        ? null
                        : (value) {
                            setState(() {
                              _rememberMe = value ?? false;
                            });
                          },
                    activeColor: const Color(0xFF1677C8),
                    side: const BorderSide(
                      color: Color(0xFF718096),
                    ),
                  ),
                ),
                const SizedBox(width: 7),
                const Text(
                  'Remember me',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: Color(0xFF65798C),
                  ),
                ),
              ],
            ),

            if (_isOtpStep) ...[
              const SizedBox(height: 15),

              Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                children: [
                  _sectionTitle(
                    'OTP Verification',
                    const Color(0xFF1677C8),
                  ),
                  TextButton(
                    onPressed: _isLoading ? null : _resendOtp,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      minimumSize: Size.zero,
                      tapTargetSize:
                          MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      'Resend OTP',
                      style: TextStyle(
                        color: Color(0xFF1677C8),
                        fontWeight: FontWeight.w700,
                        fontSize: 10.5,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 7),

              TextFormField(
                controller: _otpController,
                enabled: !_isLoading,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: _inputDecoration(
                  hintText: 'Enter 6-digit OTP',
                  icon: Icons.verified_user_outlined,
                  color: const Color(0xFF1677C8),
                ).copyWith(
                  counterText: '',
                ),
              ),

              const SizedBox(height: 8),

              _buildOtpInfo(),
            ],

            const SizedBox(height: 15),

            _buildLoginButton(),

            const SizedBox(height: 16),

            AnimatedOpacity(
              duration: const Duration(milliseconds: 300),
              opacity: _isOtpStep ? 0.30 : 1.0,
              child: IgnorePointer(
                ignoring: _isOtpStep || _isLoading,
                child: Column(
                  children: [
                    _buildDivider(),
                    const SizedBox(height: 13),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final stackButtons = constraints.maxWidth < 300;

                        final google = _socialButton(
                          icon: Icons.g_mobiledata,
                          label: 'Google',
                          accent: const Color(0xFFEA4335),
                          onPressed: () => _openSocialLogin('Google'),
                        );

                        final facebook = _socialButton(
                          icon: Icons.facebook,
                          label: 'Facebook',
                          accent: const Color(0xFF1877F2),
                          onPressed: () => _openSocialLogin('Facebook'),
                        );

                        if (stackButtons) {
                          return Column(
                            children: [
                              SizedBox(width: double.infinity, child: google),
                              const SizedBox(height: 8),
                              SizedBox(width: double.infinity, child: facebook),
                            ],
                          );
                        }

                        return Row(
                          children: [
                            Expanded(child: google),
                            const SizedBox(width: 9),
                            Expanded(child: facebook),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),

            if (!_isOtpStep) ...[
              const SizedBox(height: 16),
              Center(
                child: Wrap(
                  alignment: WrapAlignment.center,
                  children: [
                    const Text(
                      "Don't have an account? ",
                      style: TextStyle(
                        fontSize: 10.5,
                        color: Color(0xFF718096),
                      ),
                    ),
                    GestureDetector(
                      onTap: _isLoading
                          ? null
                          : () => Navigator.pushNamed(
                                context,
                                AppRoutes.signup,
                              ),
                      child: const Text(
                        'Create Account',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF1677C8),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 13),

            Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: Color(0xFF10B981),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    'Secure Enterprise Access',
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF7FA0BA),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // OTP information box.
  Widget _buildOtpInfo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 9,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F8FE),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(
          color: const Color(0xFFD7EAF8),
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.lock_clock_outlined,
            size: 16,
            color: Color(0xFF1677C8),
          ),
          SizedBox(width: 7),
          Expanded(
            child: Text(
              'Demo OTP: 123456',
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                color: Color(0xFF52718D),
              ),
            ),
          ),
          Icon(
            Icons.verified_rounded,
            size: 15,
            color: Color(0xFF10B981),
          ),
        ],
      ),
    );
  }

  // Login or OTP verification button.
  Widget _buildLoginButton() {
    return SizedBox(
      width: double.infinity,
      height: 49,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [
              Color(0xFF075EA6),
              Color(0xFF1677C8),
              Color(0xFF168FE2),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF1677C8)
                  .withValues(alpha: 0.22),
              blurRadius: 15,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: _isLoading ? null : _login,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            disabledBackgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            foregroundColor: Colors.white,
            disabledForegroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 21,
                  height: 21,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.3,
                    color: Colors.white,
                  ),
                )
              : FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _isOtpStep ? 'Verify OTP' : 'Login',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(
                        Icons.arrow_forward_rounded,
                        size: 18,
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  // Section heading.
  Widget _sectionTitle(
    String title,
    Color color,
  ) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 3,
          height: 15,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 7),
        Text(
          title,
          style: const TextStyle(
            fontSize: 11.5,
            fontWeight: FontWeight.w800,
            color: Color(0xFF243B53),
          ),
        ),
      ],
    );
  }

  // Text field decoration.
  InputDecoration _inputDecoration({
    required String hintText,
    required IconData icon,
    required Color color,
    Widget? suffixIcon,
  }) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(
        fontSize: 11.5,
        color: Color(0xFF9AAABC),
      ),
      prefixIcon: Icon(
        icon,
        color: color,
        size: 18,
      ),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: const Color(0xFFF9FBFD),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 13,
        vertical: 14,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: const BorderSide(
          color: Color(0xFFDCE7F0),
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: const BorderSide(
          color: Color(0xFFDCE7F0),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: BorderSide(
          color: color,
          width: 1.5,
        ),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: const BorderSide(
          color: Color(0xFFE4EBF1),
        ),
      ),
    );
  }

  // Divider between normal login and social login.
  Widget _buildDivider() {
    return Row(
      children: [
        const Expanded(
          child: Divider(
            color: Color(0xFFE2E8F0),
            height: 1,
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 11),
          child: Text(
            'OR',
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.w700,
              color: Color(0xFF9AA8B6),
            ),
          ),
        ),
        const Expanded(
          child: Divider(
            color: Color(0xFFE2E8F0),
            height: 1,
          ),
        ),
      ],
    );
  }

  // Social login button.
  Widget _socialButton({
    required IconData icon,
    required String label,
    required Color accent,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      height: 42,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF334155),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          side: BorderSide(
            color: accent.withValues(alpha: 0.22),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: accent,
                size: 20,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}